<?php
require 'connection.php';

if (isset($_POST['submit'])) {
    $name = $_POST["name"];
    $age = $_POST["age"];
    $country = $_POST["country"];
    $gender = $_POST["gender"];

    $languages = $_POST["languages"];
    $language = "";
    foreach ($languages as $row) {
        $language .= $row . "";
    }
    $query = "INSERT INTO tb_data VALUES('','$name','$age','$country','$gender','$language')";
    mysqli_query($conn, $query);
    echo
    "
    <script>alert('Data added Successfully');</script>
    ";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=`device-width`, initial-scale=1.0">
    <link rel="stylesheet" href="style.css" />
    <title>Insert Data</title>
</head>

<body>
    <section class="container">
        <header>Registration Form</header>
        <form class="form" action="" method="post" autocomplete="off">
            <div class="column">
                <div class="input-box">
                    <label>Full Name</label>
                    <input type="text" name="name" placeholder="Enter full name" required />
                </div>
                <div class="input-box">
                    <label for="">Age</label>
                    <input type="number" name="age" required value="" placeholder="Enter Age">
                </div>
            </div>
            <div class="gender-box">
                <h3>Gender</h3>
                <div class="gender-option">
                    <div class="gender">
                        <input type="radio" id="check-male" name="gender" value="Male" required />
                        <label for="check-male">Male</label>
                    </div>
                    <div class="gender">
                        <input type="radio" id="check-female" name="gender" value="Female" required />
                        <label for="check-female">Female</label>
                    </div>
                    <div class="gender">
                        <input type="radio" id="check-other" name="gender" value="prefer not to say" required />
                        <label for="check-other">prefer not to say</label>
                    </div>
                </div>
            </div>
            <div class="select-box">
                <select name="country" id="country" required>
                    <option value="" selected hidden>Country</option>
                    <option value="USA">USA</option>
                    <option value="Dubai">Dubai</option>
                    <option value="India">India</option>
                    <option value="Saudi Arabia">Saudi Arabia</option>
                </select>
            </div>
            <div class="gender-box">
                <h3>Language</h3>
                <div class="gender-option">
                    <input type="checkbox" name="languages[]" value="English">English
                    <input type="checkbox" name="languages[]" value="Chinese">Chinese
                    <input type="checkbox" name="languages[]" value="Spanish">Spanish
                </div>
            </div>
            <button type="submit" name="submit">Submit</button>
        </form>
    </section>
    <!-- <form class="" action="" method="post" autocomplete="off">
        <label for="">Name</label>
        <input type="text" name="name" required value="">
        <label for="">Age</label>
        <input type="number" name="age" required value="">
        <label for="">Country</label>
        <select name="country" id="country" required>
            <option value="" selected hidden>Selected Country</option>
            <option value="USA">USA</option>
            <option value="Dubai">Dubai</option>
            <option value="India">India</option>
            <option value="Saudi Arabia">Saudi Arabia</option>
        </select>
        <label for="">Gender</label>
        <input type="radio" name="gender" value="Male" required>Male
        <input type="radio" name="gender" value="Female" required>Female
        <label for="">Language</label>
        <input type="checkbox" name="languages[]" value="English">English
        <input type="checkbox" name="languages[]" value="Chinese">Chinese
        <input type="checkbox" name="languages[]" value="Spanish">Spanish
        <br />
        <button type="submit" name="submit">Submit</button>
    </form> -->
</body>

</html>